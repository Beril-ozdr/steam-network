# Steam Oyun Benzerlik Ağı

Sosyal Ağ Analizi dönem ödevi – Büyük Veri Analistliği
Hazırlayan: Beril Özdizdar

## Araştırma sorusu

Bağımsız bir oyun stüdyosu için **doymamış** (az rekabetli ama ilgi gören) etiket kombinasyonları hangileridir?

## Veri kaynağı

- Kaynak: SteamSpy API (https://steamspy.com/api.php)
- Toplama tarihi: 25 Ekim 2026
- Kapsam: SteamSpy `all` listesinin ilk 3 sayfası (3.000 oyun) alındı; bunlardan toplam değerlendirme sayısına (olumlu + olumsuz) göre en popüler **2.000 oyun** seçildi.
- Her oyun için etiketler ve etiket oy sayıları `appdetails` çağrısıyla toplandı.
- Kişisel kullanıcı verisi kullanılmadı; yalnızca oyunlara ait herkese açık veriler kullanıldı.

**Bilinen sınırlama:** İlk 3 sayfa en popüler oyunların tamamını kapsamıyor (örneğin Dota 2 listede yok). Analizdeki oyun seçimi bu listeyle sınırlıdır.

## Yöntem (ara kontrol aşaması)

- Her oyun için en çok oy alan **15 etiket** tutuldu; 5'ten az oyunda geçen etiketler atıldı (346 etiket kaldı).
- Üç ağ kuruldu:
  1. **Oyun–etiket** (iki parçalı ağ, kenar ağırlığı = etiket oy sayısı)
  2. **Etiket–etiket** projeksiyonu (ağırlık = birlikte geçtiği oyun sayısı, ayrıca Jaccard)
  3. **Oyun–oyun** projeksiyonu (etiket oy vektörlerinin kosinus benzerliği ≥ 0.5)

## Temel istatistikler

| Ağ | Düğüm | Kenar | Yoğunluk | Bileşen | En büyük bileşen |
|---|---|---|---|---|---|
| Oyun–etiket | 2346 | 29650 | 0.04285 | 1 | 2346 |
| Etiket–etiket | 346 | 22500 | 0.37698 | 1 | 346 |
| Oyun–oyun | 2000 | 53315 | 0.02667 | 39 | 1958 |

Etiket–etiket ağında ortalama kümelenme katsayısı 0.6989, oyun–oyun ağında 0.5267'dir. Oyun–oyun ağında 34 izole oyun vardır.

## Dosyalar

- `fetch_data.py` – SteamSpy'dan veri toplama
- `build_network_v2.py` – ağları kurma ve istatistik hesaplama
- `requirements.txt` – gerekli kütüphaneler
- `data/raw/` – ham veri
- `data/processed/` – kenar listeleri (CSV), GraphML dosyaları, `stats.csv`

## Çalıştırma

```
pip install -r requirements.txt
python fetch_data.py
python build_network_v2.py
```

## Yapay zekâ kullanımı

Veri toplama ve ağ kurma script'lerinin yazımında Claude (Anthropic) yapay zekâ asistanından yardım alınmıştır. Script'ler çalıştırılmış, çıktılar kontrol edilmiştir.

## Sonraki adımlar

Derece dağılımı ve merkezilik analizi, Adamic-Adar ve Jaccard ile bağlantı tahmini, çıkış yılına göre geçmiş verilerle doğrulama.
